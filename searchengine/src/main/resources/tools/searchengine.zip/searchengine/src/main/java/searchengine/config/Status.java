package searchengine.config;

public enum Status {
    INDEXING, INDEXED, FAILED
}
