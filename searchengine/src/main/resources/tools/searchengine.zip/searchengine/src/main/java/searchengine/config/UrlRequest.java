package searchengine.config;
import lombok.Data;

@Data
public class UrlRequest {
    private String url;
}
